import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.cluster import KMeans

# Load the iris dataset using pandas
file_path = r'C:\Users\walim\Documents\Projects\Python\AI\iris.data'
column_names = ['sepal_length', 'sepal_width', 'petal_length', 'petal_width', 'class']
df = pd.read_csv(file_path, header=None, names=column_names)

# Separate features (X) and target variable (y)
X = df.iloc[:, :-1]
y = df['class'] # y are labels (classes)

# Convert class labels to numerical values
le = LabelEncoder()
y_encoded = le.fit_transform(y)

# Create KMeans model and fit the data
k = 3
kmeans = KMeans(n_clusters=k)
labels = kmeans.fit_predict(X)

# Predict the cluster for new data
new_data = np.array([[4.9, 3.1, 1.5, 0.2]])  # Convert the list to a Numpy array
predicted_cluster = kmeans.predict(new_data)
print(f"Predicted Cluster for Inputed Data: {predicted_cluster}")
predicted_class = le.inverse_transform(predicted_cluster)
print(f"Predicted Class for Inputed Data: {predicted_class}")