import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.naive_bayes import GaussianNB

# Load the iris dataset
X = np.loadtxt(r'C:\Users\walim\Documents\Projects\Python\AI\iris.data', delimiter=',', usecols=(0, 1, 2, 3))
y = np.loadtxt(r'C:\Users\walim\Documents\Projects\Python\AI\iris.data', delimiter=',', usecols=(4), dtype=str)

# y is used to show label data
le = LabelEncoder()
y = le.fit_transform(y)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

gnb = GaussianNB()
gnb.fit(X_train, y_train)

accuracy_train = gnb.score(X_train, y_train)
print("Trainig Accuracy:",accuracy_train)

accuracy_test = gnb.score(X_test, y_test)
print("Testing Accuracy:",accuracy_test)

new_data = [[4.9, 3.1, 1.5, 0.2]]
prediction = gnb.predict(new_data)
print("Predicted Class",prediction)

print("It belongs to ",le.inverse_transform(gnb.predict(new_data)))